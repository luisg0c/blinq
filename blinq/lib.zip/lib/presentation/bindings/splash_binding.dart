import 'package:get/get.dart';

class SplashBinding extends Bindings {
  @override
  void dependencies() {
    // Nenhuma dependência por enquanto
  }
}
