import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../domain/entities/transaction.dart';

/// Modelo de transação compatível com a estrutura YeezyBank.
class TransactionModel extends Transaction {
  // Campos adicionais para YeezyBank (não expostos na entidade)
  final String senderId;
  final String? receiverId;
  final List<String> participants;

  const TransactionModel({
    required String id,
    required double amount,
    required DateTime date,
    required String description,
    required String type,
    required String counterparty,
    required String status,
    required this.senderId,
    this.receiverId,
    required this.participants,
  }) : super(
          id: id,
          amount: amount,
          date: date,
          description: description,
          type: type,
          counterparty: counterparty,
          status: status,
        );

  /// Cria um [TransactionModel] a partir de dados do Firestore.
  factory TransactionModel.fromFirestore(String id, Map<String, dynamic> data) {
    final timestamp = data['timestamp'] as Timestamp?;
    final participantsList = List<String>.from(data['participants'] ?? []);

    return TransactionModel(
      id: id,
      senderId: data['senderId'] ?? '',
      receiverId: data['receiverId'],
      amount: (data['amount'] as num?)?.toDouble() ?? 0.0,
      date: timestamp?.toDate() ?? DateTime.now(),
      participants: participantsList,
      type: data['type'] ?? '',
      description: data['description'] ?? '',
      counterparty: data['receiverId'] ?? '',
      status: 'completed',
    );
  }

  /// Cria um [TransactionModel] a partir de uma entidade de domínio.
  factory TransactionModel.fromEntity(Transaction transaction) {
    return TransactionModel(
      id: transaction.id,
      senderId: '', // Será definido no serviço
      receiverId: transaction.type == 'transfer' ? transaction.counterparty : null,
      amount: transaction.amount,
      date: transaction.date,
      participants: [], // Será definido no serviço
      type: transaction.type,
      description: transaction.description,
      counterparty: transaction.counterparty,
      status: transaction.status,
    );
  }

  /// Converte para Map do Firestore seguindo estrutura YeezyBank.
  Map<String, dynamic> toFirestore() {
    return {
      'senderId': senderId,
      'receiverId': receiverId,
      'amount': amount,
      'timestamp': Timestamp.fromDate(date),
      'participants': participants,
      'type': type,
      'description': description,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }

  /// Cria transação de depósito para YeezyBank.
  factory TransactionModel.deposit({
    required String id,
    required String userId,
    required double amount,
    String? description,
  }) {
    return TransactionModel(
      id: id,
      senderId: userId,
      receiverId: null,
      amount: amount,
      date: DateTime.now(),
      participants: [userId],
      type: 'deposit',
      description: description ?? 'Depósito',
      counterparty: '',
      status: 'completed',
    );
  }

  /// Cria transação de transferência PIX para YeezyBank.
  factory TransactionModel.transfer({
    required String id,
    required String senderId,
    required String receiverId,
    required double amount,
    String? description,
  }) {
    return TransactionModel(
      id: id,
      senderId: senderId,
      receiverId: receiverId,
      amount: amount,
      date: DateTime.now(),
      participants: [senderId, receiverId],
      type: 'transfer',
      description: description ?? 'Transferência PIX',
      counterparty: receiverId,
      status: 'completed',
    );
  }
}