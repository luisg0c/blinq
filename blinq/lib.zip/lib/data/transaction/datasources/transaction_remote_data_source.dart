import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../domain/entities/transaction.dart';
import '../models/transaction_model.dart';

/// Contrato para operações de transação no Firebase.
abstract class TransactionRemoteDataSource {
  Future<void> addTransaction(TransactionModel transaction);
  Future<List<Transaction>> getTransactionsByUser(String userId);
  Future<List<Transaction>> getTransactionsBetween({
    required String userId,
    required DateTime start,
    required DateTime end,
  });
  Stream<List<Transaction>> watchTransactionsByUser(String userId);
}

/// Implementação usando Firestore seguindo estrutura YeezyBank.
class TransactionRemoteDataSourceImpl implements TransactionRemoteDataSource {
  final FirebaseFirestore _firestore;

  TransactionRemoteDataSourceImpl({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  @override
  Future<void> addTransaction(TransactionModel transaction) async {
    await _firestore
        .collection('transactions')
        .doc(transaction.id)
        .set(transaction.toFirestore());
  }

  @override
  Future<List<Transaction>> getTransactionsByUser(String userId) async {
    final snapshot = await _firestore
        .collection('transactions')
        .where('participants', arrayContains: userId)
        .orderBy('timestamp', descending: true)
        .get();

    return snapshot.docs
        .map((doc) => TransactionModel.fromFirestore(doc.id, doc.data()))
        .toList();
  }

  @override
  Future<List<Transaction>> getTransactionsBetween({
    required String userId,
    required DateTime start,
    required DateTime end,
  }) async {
    final snapshot = await _firestore
        .collection('transactions')
        .where('participants', arrayContains: userId)
        .where('timestamp', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('timestamp', isLessThanOrEqualTo: Timestamp.fromDate(end))
        .orderBy('timestamp', descending: true)
        .get();

    return snapshot.docs
        .map((doc) => TransactionModel.fromFirestore(doc.id, doc.data()))
        .toList();
  }

  @override
  Stream<List<Transaction>> watchTransactionsByUser(String userId) {
    return _firestore
        .collection('transactions')
        .where('participants', arrayContains: userId)
        .orderBy('timestamp', descending: true)
        .limit(50) // Limita para performance
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => TransactionModel.fromFirestore(doc.id, doc.data()))
            .toList());
  }
}