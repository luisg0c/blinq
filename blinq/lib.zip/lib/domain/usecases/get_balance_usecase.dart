import '../repositories/transaction_repository.dart';

class GetBalanceUseCase {
  final TransactionRepository repository;

  GetBalanceUseCase(this.repository);

  Future<double> execute() {
    return repository.getBalance();
  }
}
